console.info('chrome-ext template-react-js background script')

export {}
